function busqueda() {
    var dado = Math.floor(1 + aleat * 6);

    document.writeln("<h2>EL valor del dado es " + dado + "</h2>");
    document.writeln("<img src='imagenes/dados/" + dado + ".jpg' >");
}